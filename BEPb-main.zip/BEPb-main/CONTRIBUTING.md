## Assistance
### Adding a language
I invite you to contribute by translating this page into your native language

### Adding content
Offer materials to saturate the page, in my humble opinion I have collected the best and brightest elements of a 
programmer's business card, but perhaps you know more about what I don't know, I'm open for dialogue. 